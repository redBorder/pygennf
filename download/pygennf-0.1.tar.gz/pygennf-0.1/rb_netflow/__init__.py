### This file is part of pygennf
### See https://github.com/redBorder
### Ana Rey <anarey@redborder.com>
### This program is published under AGPL license
